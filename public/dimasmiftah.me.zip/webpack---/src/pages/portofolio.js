import React from "react"
import Layout from "../components/Layout/Layout"
import Portfolio from "../components/Content/Portfolio/Portfolio"

export default function Home() {
    return ( <
        Layout >
        <
        Portfolio / >
        <
        /Layout>
    )
}